"""CONSOLE AI application modules."""
